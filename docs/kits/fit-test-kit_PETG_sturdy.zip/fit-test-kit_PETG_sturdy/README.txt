FIT TEST KIT - PETG, sturdy rails
For the Drawer Wall Builder: https://mhrahimi.github.io/3d_printables/
Instructions with pictures: https://mhrahimi.github.io/3d_printables/docs/fit-test-kit.html

Print everything here (about 100 g) before the wall, with the settings you will use for it:
0.4 mm nozzle, 0.20 mm layers, 3 walls, 15% infill, no supports. Do not rotate or scale.
The number in front of each file name is how many to print.

RAILS
  Slide each test_groove piece onto test_rail. 3 V-notches is the PETG preset
  (0.30 mm per side); each notch more or fewer is 0.05 mm looser or tighter.
  Pick the tightest piece that slides the full length by hand without wobble.

DRAWERS
  Slide each test_drawer_slice into test_drawer_opening. 2 notches is the preset
  (0.40 mm per side); 1 notch is 0.10 mm tighter, 3 notches 0.10 mm looser.
  Pick the one that slides freely without rattling.

THEN
  If a piece other than the preset fitted best, set the difference in the builder under
  3 Print > Advanced (rail clearance and drawer clearance) before downloading your wall.
  Join the two mini casings and try the mini drawer to feel both clicks.

Made for the standard 60 x 40 mm unit and sturdy rails (2 mm high, 6 mm neck).
